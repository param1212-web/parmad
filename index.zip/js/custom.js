$(".hem").click(function(){
    
  $(".navigation").toggleClass("resmn");
  $(this).toggleClass('toggle');
   $("body").toggleClass("slip");
});

$(".list").click(function(){
  $(".navigation").toggleClass("resmn");
  $(".hem").toggleClass('toggle');
  $("body").toggleClass("slip");


  
});


$(document).ready(function () {
  $(".navigation ul li a").click(function () {
    $(".navigation ul li a").removeClass("active");
    $(this).addClass("active");
  });

  $(".logo a").click(function () {
    $(".navigation ul li a").removeClass("active");

  });

  $(".trigger").click(function () {
    $(".navigation ul").slideToggle("active");

  });


  if ($(window).width() < 768) {
    $(".navigation ul li a").click(function () {
      $(".navigation ul").slideUp();

    });
  }
  else {

  }



$(".form-row .sub input, .form-row .sub textarea").focus(function () {
    $(this).parents(".fldWrp").addClass("active");
  });

  $(".form-row .sub input, .form-row .sub textarea").blur(function () {
    var inputValue = $(this).val();
    if (inputValue == "") {
      $(this).removeClass("filled");
      $(this).parents(".fldWrp").removeClass("active");
    } else {
      $(this).addClass("filled");
    }
  });




});


$(document).ready(function () {
  $(".loader").delay(700).fadeOut("slow");
  $("#overlayer").delay(700).fadeOut("slow");
})


$(document).ready(function() {
  // Function to animate counting from 0 to the end value within the element
  function countUp(element, duration) {
    var endValue = parseFloat(element.text());
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      element.text(Math.round(endValue * progress));
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    }

    requestAnimationFrame(step);
  }

  // Start counting for all elements with the class "count-up"
  $(".count-up").each(function() {
    countUp($(this), 2000); // Adjust the duration (in milliseconds) as needed
  });
});

$('.form_control input, .form_control textarea').focus(function(){
  $(this).parents('.form_control').addClass('active');
});

$('.form_control input, .form_control textarea').blur(function(){
  var inputValue = $(this).val();
  if (inputValue == "") {
    $(this).removeClass('filled');
    $(this).parents('.form_control').removeClass('active');  
  } else {
    $(this).addClass('filled');
  }
});



$(window).scroll(function(){
  if ($(this).scrollTop() > 0) {

    $('.nrBd').addClass('bdPad');
     $('.main_header').addClass('fixed');
  } else {
    $('.nrBd').removeClass('bdPad'); 
    $('.main_header').removeClass('fixed');
  }
});

new WOW().init();

// menu

$(".trigger").click(function(){
  $("body").toggleClass("slip");
});

$(".menu_overlay").click(function(){
  $("body").removeClass("slip");
});


$(".sub_menu_trigger").click(function(event){
  event.preventDefault();
if ($(this).parents(".has_dropdown").hasClass("open")) {
  $(this).parents(".has_dropdown").removeClass("open");
  $(this).next(".sub_menus").slideUp();
}else{
  
  $(".has_dropdown").removeClass("open");
  $(".sub_menus").slideUp();
  $(this).parents(".has_dropdown").addClass("open");
  $(this).next(".sub_menus").slideDown();	
}    
});

$(".sub_menu").click(function(){
  
  $("body").toggleClass("slip");
});

$(".blklink").click(function() {
  $("body").removeClass("slip");
});

// menu end

var sections = $('.single_card')
  , nav = $('.mission_nav')
  , nav_height = nav.outerHeight();

$(window).on('scroll', function () {
  var cur_pos = $(this).scrollTop();
  
  sections.each(function() {
    var top = $(this).offset().top - 600,
        bottom = top + $(this).outerHeight();
    
    if (cur_pos >= top && cur_pos <= bottom) {
      nav.find('a').removeClass('active');
      sections.removeClass('active');
      
      $(this).addClass('active');
      nav.find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
    }
  });
});

$(document).ready(function () {
  $(".loader").delay(700).fadeOut("slow");
  $("#overlayer").delay(700).fadeOut("slow");
})


$(".faq_inner ul li h3").click(function(){
  if ($(this).hasClass("active")) {
    $(this).parent("li").find(".faq_content").slideUp();
    $(this).removeClass("active");
  }else{
    $(".faq_content").slideUp();
    $(".faq_inner ul li h3").removeClass("active");
    $(this).parent("li").find(".faq_content").slideDown();
    $(this).addClass("active");
  }
});